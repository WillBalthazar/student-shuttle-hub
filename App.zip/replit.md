# School Monitor

A mobile-first web app for school monitors to manage student transport to special classes (Aulas Especiais). Shows student photos in a grid by schedule, with tap-to-toggle status and press-and-hold for student details. Fully in Portuguese.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 8080)
- `pnpm --filter @workspace/student-transport run dev` — run the frontend (port 24328)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL`, `SESSION_SECRET` — Postgres connection string + session secret

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- Frontend: React + Vite + Tailwind CSS + Framer Motion
- API: Express 5 + express-session
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `lib/api-spec/openapi.yaml` — OpenAPI contract (source of truth)
- `lib/db/src/schema/` — DB tables: `schedules.ts`, `students.ts`, `studentStatuses.ts`, `monitors.ts`
- `artifacts/api-server/src/routes/` — API routes: `auth.ts`, `schedules.ts`, `students.ts`
- `artifacts/student-transport/src/` — React frontend
- `artifacts/student-transport/src/hooks/use-auth.tsx` — Auth context (monitor session)
- `artifacts/student-transport/src/pages/login.tsx` — PIN login page
- `lib/api-client-react/src/generated/` — Generated React Query hooks
- `lib/api-zod/src/generated/` — Generated Zod schemas

## Architecture decisions

- Status (present/absent) is stored in a separate `student_statuses` table — allows tracking per-schedule per-student without mutating the student record
- PATCH /students/:id/status uses upsert logic (insert or update) for idempotency
- Frontend uses optimistic updates for instant tap feedback on student cards
- Long-press (500ms) detection done via useRef timers on the card, not a separate button
- Schedules are defined at the schedule level; students are assigned to one schedule via `schedule_id`
- Monitor auth uses express-session with PIN hashed via bcryptjs

## Product

- Login: monitor selects their name, enters 4-digit PIN
- Schedule list (Horários): shows all daily time slots with Retirada time, Presente/Ausente counts
- Student grid (Alunos): photo grid filtered by schedule, tap to toggle Presente/Ausente
- Student detail drawer (Detalhes do Aluno): opens on press-and-hold with Responsável, Contato, Horário, Aulas Especiais, Retirada, Observações Médicas

## Monitors & PINs (seeded)

| Monitor        | PIN  |
|----------------|------|
| Ana Lima       | 1234 |
| Carlos Souza   | 5678 |
| Maria Oliveira | 9999 |

## User preferences

_Populate as you build — explicit user instructions worth remembering across sessions._

## Gotchas

- Always run `pnpm run typecheck:libs` after changing DB schema files (they're composite libs)
- Run codegen after any OpenAPI spec change before using new types
- `student_statuses` starts empty — all students default to "absent" until toggled

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
