import { useEffect, useState, useRef } from "react";
import { useToast } from "@/hooks/use-toast";
import type { Schedule, ScheduleSummary } from "@workspace/api-client-react";

function parseMinutes(time: string): number {
  const [h, m] = time.split(":").map(Number);
  return (h ?? 0) * 60 + (m ?? 0);
}

function playChime(type: "warning" | "alert") {
  try {
    const AudioCtx =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext: typeof AudioContext })
        .webkitAudioContext;
    const ctx = new AudioCtx();
    const notes =
      type === "warning"
        ? [523, 659, 523]
        : [659, 784, 659, 784];
    let t = ctx.currentTime;
    notes.forEach((freq) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = "sine";
      osc.frequency.setValueAtTime(freq, t);
      gain.gain.setValueAtTime(0, t);
      gain.gain.linearRampToValueAtTime(0.12, t + 0.04);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.45);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(t);
      osc.stop(t + 0.45);
      t += 0.5;
    });
    setTimeout(() => ctx.close(), (t + 0.6) * 1000);
  } catch {
    // Audio not supported
  }
}

function vibrate(pattern: number[]) {
  try {
    navigator.vibrate?.(pattern);
  } catch {}
}

function getFiredAlerts(): Set<string> {
  try {
    const stored = sessionStorage.getItem("fired_schedule_alerts");
    return new Set(stored ? JSON.parse(stored) : []);
  } catch {
    return new Set();
  }
}

function markAlertFired(key: string) {
  try {
    const alerts = getFiredAlerts();
    alerts.add(key);
    sessionStorage.setItem(
      "fired_schedule_alerts",
      JSON.stringify([...alerts])
    );
  } catch {}
}

async function sendBrowserNotification(title: string, body: string) {
  try {
    if ("Notification" in window && Notification.permission === "granted") {
      new Notification(title, { body, icon: "/favicon.svg" });
    }
  } catch {}
}

export interface OverdueSchedule {
  scheduleId: number;
  scheduleName: string;
  pendingCount: number;
  departureTime: string;
}

export function useScheduleAlerts(
  schedules: Schedule[] | undefined,
  summaries: ScheduleSummary[] | undefined
): OverdueSchedule[] {
  const { toast } = useToast();
  const [overdueSchedules, setOverdueSchedules] = useState<OverdueSchedule[]>([]);
  const schedulesRef = useRef(schedules);
  const summariesRef = useRef(summaries);
  schedulesRef.current = schedules;
  summariesRef.current = summaries;
  const toastRef = useRef(toast);
  toastRef.current = toast;

  useEffect(() => {
    const check = () => {
      const schedules = schedulesRef.current;
      const summaries = summariesRef.current;
      if (!schedules || !summaries) return;

      const now = new Date();
      const currentMinutes = now.getHours() * 60 + now.getMinutes();
      const overdue: OverdueSchedule[] = [];

      for (const schedule of schedules) {
        const summary = summaries.find((s) => s.scheduleId === schedule.id);
        if (!summary) continue;

        const depMinutes = parseMinutes(schedule.departureTime);
        const diff = depMinutes - currentMinutes;

        // Overdue: past departure + pending (unset) students + not finalized
        if (
          currentMinutes >= depMinutes &&
          summary.pendingCount > 0 &&
          !summary.isFinalized
        ) {
          overdue.push({
            scheduleId: schedule.id,
            scheduleName: summary.scheduleName,
            pendingCount: summary.pendingCount,
            departureTime: schedule.departureTime,
          });
        }

        // 5-minute warning (diff is 4–6 minutes)
        const warnKey = `${schedule.id}_warn`;
        if (diff >= 4 && diff <= 6 && !getFiredAlerts().has(warnKey)) {
          markAlertFired(warnKey);
          toastRef.current({
            title: "Retirada em 5 minutos",
            description: `${schedule.name} — ${schedule.departureTime}`,
          });
          playChime("warning");
          vibrate([100, 60, 100]);
          sendBrowserNotification(
            "Retirada em 5 minutos",
            `${schedule.name} — ${schedule.departureTime}`
          );
        }

        // At departure (diff is -1 to +1 minute)
        const alertKey = `${schedule.id}_alert`;
        if (diff >= -1 && diff <= 1 && !getFiredAlerts().has(alertKey)) {
          markAlertFired(alertKey);
          toastRef.current({
            title: "Hora da Retirada!",
            description: `${schedule.name} — ${schedule.departureTime}`,
            variant: "destructive",
          });
          playChime("alert");
          vibrate([200, 100, 200, 100, 200]);
          sendBrowserNotification(
            "Hora da Retirada!",
            `${schedule.name} — saída agora`
          );
        }
      }

      setOverdueSchedules(overdue);
    };

    check();
    const interval = setInterval(check, 30_000);
    return () => clearInterval(interval);
  }, []);

  return overdueSchedules;
}

export function requestNotificationPermission() {
  if ("Notification" in window && Notification.permission === "default") {
    Notification.requestPermission().catch(() => {});
  }
}
