import { useEffect, useState } from "react";
import { useToast } from "@/hooks/use-toast";

export function useOffline() {
  const { toast } = useToast();
  const [isOffline, setIsOffline] = useState(() => !navigator.onLine);

  useEffect(() => {
    const handleOffline = () => {
      setIsOffline(true);
      toast({
        title: "Sem conexão",
        description: "Trabalhando offline. Os dados podem estar desatualizados.",
        variant: "destructive",
      });
    };

    const handleOnline = () => {
      setIsOffline(false);
      toast({
        title: "Conexão restaurada",
        description: "Sincronizando dados com o servidor...",
      });
    };

    window.addEventListener("offline", handleOffline);
    window.addEventListener("online", handleOnline);
    return () => {
      window.removeEventListener("offline", handleOffline);
      window.removeEventListener("online", handleOnline);
    };
  }, [toast]);

  return { isOffline };
}
