import { createContext, useContext, useState, useEffect, useCallback, type ReactNode } from "react";

interface Monitor {
  id: number;
  name: string;
}

interface AuthContextValue {
  monitor: Monitor | null;
  isLoading: boolean;
  login: (monitorId: number, pin: string) => Promise<{ error?: string }>;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [monitor, setMonitor] = useState<Monitor | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    fetch("/api/auth/me", { credentials: "include" })
      .then((r) => (r.ok ? r.json() : null))
      .then((data) => setMonitor(data))
      .catch(() => setMonitor(null))
      .finally(() => setIsLoading(false));
  }, []);

  const login = useCallback(async (monitorId: number, pin: string) => {
    const res = await fetch("/api/auth/login", {
      method: "POST",
      credentials: "include",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ monitorId, pin }),
    });
    const data = await res.json();
    if (!res.ok) return { error: data.error ?? "Erro ao entrar" };
    setMonitor(data);
    return {};
  }, []);

  const logout = useCallback(async () => {
    await fetch("/api/auth/logout", { method: "POST", credentials: "include" });
    setMonitor(null);
  }, []);

  return (
    <AuthContext.Provider value={{ monitor, isLoading, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used inside AuthProvider");
  return ctx;
}
