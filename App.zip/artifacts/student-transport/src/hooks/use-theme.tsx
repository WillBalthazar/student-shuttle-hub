import { createContext, useContext, useEffect, useState } from "react";

export type Theme = "light" | "dark" | "system";

interface AppSettings {
  theme: Theme;
  setTheme: (theme: Theme) => void;
  resolvedTheme: "light" | "dark";
  logoUrl: string;
  setLogoUrl: (url: string) => void;
}

const AppSettingsContext = createContext<AppSettings>({
  theme: "system",
  setTheme: () => {},
  resolvedTheme: "light",
  logoUrl: "",
  setLogoUrl: () => {},
});

export function AppSettingsProvider({ children }: { children: React.ReactNode }) {
  const [theme, setThemeState] = useState<Theme>(() => {
    try {
      return (localStorage.getItem("app_theme") as Theme) ?? "system";
    } catch {
      return "system";
    }
  });

  const [resolvedTheme, setResolvedTheme] = useState<"light" | "dark">("light");

  const [logoUrl, setLogoUrlState] = useState<string>(() => {
    try {
      return localStorage.getItem("app_logo_url") ?? "";
    } catch {
      return "";
    }
  });

  useEffect(() => {
    const root = document.documentElement;
    const prefersDark = window.matchMedia("(prefers-color-scheme: dark)");

    const apply = (t: Theme) => {
      const isDark = t === "dark" || (t === "system" && prefersDark.matches);
      root.classList.toggle("dark", isDark);
      setResolvedTheme(isDark ? "dark" : "light");
    };

    apply(theme);

    const listener = () => {
      if (theme === "system") apply("system");
    };
    prefersDark.addEventListener("change", listener);
    return () => prefersDark.removeEventListener("change", listener);
  }, [theme]);

  const setTheme = (t: Theme) => {
    try {
      localStorage.setItem("app_theme", t);
    } catch {}
    setThemeState(t);
  };

  const setLogoUrl = (url: string) => {
    try {
      localStorage.setItem("app_logo_url", url);
    } catch {}
    setLogoUrlState(url);
  };

  return (
    <AppSettingsContext.Provider
      value={{ theme, setTheme, resolvedTheme, logoUrl, setLogoUrl }}
    >
      {children}
    </AppSettingsContext.Provider>
  );
}

export function useAppSettings() {
  return useContext(AppSettingsContext);
}
