import { AlertTriangle } from "lucide-react";
import type { OverdueSchedule } from "@/hooks/use-schedule-alerts";

interface PendingWarningBannerProps {
  overdueSchedules: OverdueSchedule[];
}

export function PendingWarningBanner({
  overdueSchedules,
}: PendingWarningBannerProps) {
  if (overdueSchedules.length === 0) return null;

  const totalPending = overdueSchedules.reduce(
    (sum, s) => sum + s.pendingCount,
    0
  );

  return (
    <div className="bg-destructive text-destructive-foreground">
      <div className="max-w-2xl mx-auto px-4 py-3 flex items-start gap-3">
        <AlertTriangle className="w-5 h-5 shrink-0 mt-0.5" />
        <div className="flex-1 min-w-0">
          <p className="font-bold text-sm leading-tight">
            {totalPending} aluno{totalPending !== 1 ? "s" : ""} sem registro após horário de saída
          </p>
          <p className="text-xs mt-0.5 opacity-90 leading-tight">
            {overdueSchedules.map((s) => s.scheduleName).join(", ")}
          </p>
        </div>
      </div>
    </div>
  );
}
