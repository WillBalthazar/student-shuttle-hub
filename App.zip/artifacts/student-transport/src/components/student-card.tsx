import { useState, useRef, useCallback } from "react";
import type { StudentWithStatus } from "@workspace/api-client-react";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { UserX, UserCheck, CheckCircle2 } from "lucide-react";
import { cn } from "@/lib/utils";

export interface StudentCardProps {
  student: StudentWithStatus;
  onToggleStatus: (studentId: number, currentStatus: string) => void;
  onLongPress: (studentId: number) => void;
  overdue?: boolean;
}

export function StudentCard({
  student,
  onToggleStatus,
  onLongPress,
  overdue = false,
}: StudentCardProps) {
  const status = student.status as "present" | "absent" | "collected" | "unset";
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const [isPressing, setIsPressing] = useState(false);

  const startPress = useCallback(() => {
    setIsPressing(true);
    timerRef.current = setTimeout(() => {
      onLongPress(student.id);
      setIsPressing(false);
    }, 500);
  }, [student.id, onLongPress]);

  const cancelPress = useCallback(() => {
    if (timerRef.current) {
      clearTimeout(timerRef.current);
      timerRef.current = null;
    }
    if (isPressing) {
      onToggleStatus(student.id, status);
    }
    setIsPressing(false);
  }, [isPressing, onToggleStatus, student.id, status]);

  const cancelPressWithoutToggle = useCallback(() => {
    if (timerRef.current) {
      clearTimeout(timerRef.current);
      timerRef.current = null;
    }
    setIsPressing(false);
  }, []);

  const cardClass = cn(
    "relative flex flex-col items-center justify-center p-3 rounded-xl border-2 transition-all duration-200 select-none overflow-hidden touch-manipulation min-h-[120px]",
    status === "present" && "border-success bg-success/10",
    status === "absent" && [
      "border-destructive bg-destructive/10",
      overdue && "bg-destructive/20 shadow-[0_0_0_2px_hsl(var(--destructive)/0.25)]",
    ],
    status === "collected" && "border-sky-400 bg-sky-50 dark:bg-sky-950/30",
    status === "unset" && "border-dashed border-muted-foreground/30 bg-muted/30",
    isPressing && "scale-95 opacity-80"
  );

  return (
    <div
      className={cardClass}
      onPointerDown={startPress}
      onPointerUp={cancelPress}
      onPointerLeave={cancelPressWithoutToggle}
      onPointerCancel={cancelPressWithoutToggle}
      onContextMenu={(e) => e.preventDefault()}
    >
      <Avatar
        className={cn(
          "w-14 h-14 border-2 shadow-sm mb-2",
          status === "unset" ? "border-muted opacity-60" : "border-background"
        )}
      >
        <AvatarImage src={student.photoUrl} alt={student.name} />
        <AvatarFallback
          className={cn(
            "text-lg font-bold",
            status === "unset"
              ? "bg-muted text-muted-foreground"
              : "bg-secondary text-secondary-foreground"
          )}
        >
          {student.name.charAt(0)}
        </AvatarFallback>
      </Avatar>

      <div className="text-center w-full">
        <h3
          className={cn(
            "font-bold text-sm leading-tight truncate px-1",
            status === "unset" ? "text-muted-foreground" : "text-foreground"
          )}
        >
          {student.name}
        </h3>
        <p className="text-xs font-medium opacity-70 truncate text-foreground/70 mt-0.5">
          {student.grade}
        </p>
      </div>

      {/* Status badge */}
      {status === "absent" && (
        <div className="absolute top-1.5 left-1.5 flex items-center gap-0.5 bg-destructive text-destructive-foreground rounded-full px-1.5 py-0.5 text-[9px] font-bold uppercase tracking-wide leading-none">
          <UserX className="w-2.5 h-2.5" />
          Faltou
        </div>
      )}
      {status === "collected" && (
        <div className="absolute top-1.5 left-1.5 flex items-center gap-0.5 bg-sky-500 text-white rounded-full px-1.5 py-0.5 text-[9px] font-bold uppercase tracking-wide leading-none">
          <CheckCircle2 className="w-2.5 h-2.5" />
          Retirado
        </div>
      )}
      {status === "present" && (
        <div className="absolute top-1.5 right-1.5">
          <UserCheck className="w-3.5 h-3.5 text-success" />
        </div>
      )}
    </div>
  );
}
