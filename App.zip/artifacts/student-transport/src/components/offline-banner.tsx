import { WifiOff } from "lucide-react";

interface OfflineBannerProps {
  isOffline: boolean;
}

export function OfflineBanner({ isOffline }: OfflineBannerProps) {
  if (!isOffline) return null;

  return (
    <div className="bg-destructive text-destructive-foreground px-4 py-2 flex items-center justify-center gap-2 text-sm font-semibold z-50">
      <WifiOff className="w-4 h-4 shrink-0" />
      <span>Sem conexão — exibindo dados em cache</span>
    </div>
  );
}
