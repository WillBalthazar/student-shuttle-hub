import { useState } from "react";
import { useGetStudent, useUpdateStudentStatus } from "@workspace/api-client-react";
import {
  Drawer,
  DrawerContent,
  DrawerHeader,
  DrawerTitle,
  DrawerDescription,
  DrawerFooter,
  DrawerClose,
} from "@/components/ui/drawer";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Phone,
  Users,
  FileText,
  Clock,
  MapPin,
  School,
  UserX,
  CheckCircle2,
} from "lucide-react";
import { cn } from "@/lib/utils";

interface StudentDrawerProps {
  studentId: number | null;
  currentStatus?: string;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onStatusChange?: (studentId: number, newStatus: string) => void;
}

export function StudentDrawer({
  studentId,
  currentStatus,
  open,
  onOpenChange,
  onStatusChange,
}: StudentDrawerProps) {
  const [pendingAction, setPendingAction] = useState<"absent" | "collected" | null>(null);
  const [lastAction, setLastAction] = useState<"absent" | "collected" | null>(null);

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const { data: student, isLoading } = useGetStudent(studentId as number, {
    query: { enabled: !!studentId && open } as any,
  });

  const updateStatus = useUpdateStudentStatus();

  const handleAction = (newStatus: "absent" | "collected") => {
    if (!student || !studentId) return;
    setPendingAction(newStatus);

    updateStatus.mutate(
      {
        studentId,
        data: { status: newStatus, scheduleId: student.scheduleId },
      },
      {
        onSuccess: () => {
          setLastAction(newStatus);
          onStatusChange?.(studentId, newStatus);
          setTimeout(() => {
            onOpenChange(false);
            setLastAction(null);
          }, 800);
        },
        onSettled: () => setPendingAction(null),
      }
    );
  };

  const handleOpenChange = (v: boolean) => {
    if (!v) {
      setPendingAction(null);
      setLastAction(null);
    }
    onOpenChange(v);
  };

  const isAlreadyAbsent = currentStatus === "absent";
  const isAlreadyCollected = currentStatus === "collected";

  return (
    <Drawer open={open} onOpenChange={handleOpenChange}>
      <DrawerContent className="bg-background border-t border-border">
        <div className="mx-auto w-full max-w-md">
          {isLoading || !student ? (
            <div className="p-6 space-y-6">
              <div className="flex items-center gap-4">
                <Skeleton className="w-20 h-20 rounded-full" />
                <div className="space-y-2 flex-1">
                  <Skeleton className="h-6 w-3/4" />
                  <Skeleton className="h-4 w-1/2" />
                </div>
              </div>
              <div className="space-y-3">
                <Skeleton className="h-16 w-full" />
                <Skeleton className="h-16 w-full" />
              </div>
            </div>
          ) : (
            <>
              {/* Student header */}
              <DrawerHeader className="text-left flex flex-row items-center gap-4 border-b border-border/50 pb-5 pt-5">
                <Avatar className="w-16 h-16 border-2 border-border shadow-sm shrink-0">
                  <AvatarImage src={student.photoUrl} alt={student.name} />
                  <AvatarFallback className="text-xl font-bold bg-secondary text-secondary-foreground">
                    {student.name.charAt(0)}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <DrawerTitle className="text-xl font-bold text-foreground leading-tight">
                    {student.name}
                  </DrawerTitle>
                  <DrawerDescription className="text-sm font-semibold text-muted-foreground mt-0.5">
                    Turma: {student.grade}
                  </DrawerDescription>
                </div>
              </DrawerHeader>

              {/* Action buttons */}
              <div className="px-5 pt-5 pb-3">
                <p className="text-xs font-bold uppercase tracking-wider text-muted-foreground mb-3">
                  Registrar Ação
                </p>

                {lastAction && (
                  <div
                    className={cn(
                      "flex items-center gap-2 text-sm font-semibold mb-3 px-3 py-2.5 rounded-xl border",
                      lastAction === "absent"
                        ? "text-destructive bg-destructive/10 border-destructive/20"
                        : "text-sky-600 bg-sky-50 border-sky-200 dark:bg-sky-950/30 dark:border-sky-800"
                    )}
                  >
                    <CheckCircle2 className="w-4 h-4 shrink-0" />
                    {lastAction === "absent"
                      ? "Falta registrada com sucesso"
                      : "Retirada pelo responsável registrada"}
                  </div>
                )}

                <div className="grid grid-cols-2 gap-3">
                  {/* Aluno faltou */}
                  <button
                    onClick={() => handleAction("absent")}
                    disabled={updateStatus.isPending}
                    className={cn(
                      "flex flex-col items-center justify-center gap-2 h-20 rounded-xl border-2 font-bold text-sm transition-all active:scale-95",
                      isAlreadyAbsent
                        ? "border-destructive bg-destructive text-destructive-foreground"
                        : "border-destructive/40 bg-destructive/5 text-destructive hover:bg-destructive/10",
                      pendingAction === "absent" && "opacity-70 cursor-wait"
                    )}
                  >
                    <UserX className="w-6 h-6" />
                    <span>{pendingAction === "absent" ? "Registrando..." : "Aluno faltou"}</span>
                    {isAlreadyAbsent && (
                      <span className="text-[10px] font-bold opacity-80 -mt-1">✓ Registrado</span>
                    )}
                  </button>

                  {/* Pai retirou */}
                  <button
                    onClick={() => handleAction("collected")}
                    disabled={updateStatus.isPending}
                    className={cn(
                      "flex flex-col items-center justify-center gap-2 h-20 rounded-xl border-2 font-bold text-sm transition-all active:scale-95",
                      isAlreadyCollected
                        ? "border-sky-500 bg-sky-500 text-white"
                        : "border-sky-300 bg-sky-50 text-sky-700 hover:bg-sky-100 dark:bg-sky-950/30 dark:border-sky-700 dark:text-sky-300",
                      pendingAction === "collected" && "opacity-70 cursor-wait"
                    )}
                  >
                    <CheckCircle2 className="w-6 h-6" />
                    <span>{pendingAction === "collected" ? "Registrando..." : "Pai retirou"}</span>
                    {isAlreadyCollected && (
                      <span className="text-[10px] font-bold opacity-80 -mt-1">✓ Registrado</span>
                    )}
                  </button>
                </div>
              </div>

              {/* Student details */}
              <div className="px-5 py-3 space-y-4">
                <p className="text-xs font-bold uppercase tracking-wider text-muted-foreground">
                  Detalhes do Aluno
                </p>
                <div className="grid grid-cols-1 gap-4">
                  <div className="flex items-start gap-3">
                    <Users className="w-4 h-4 text-muted-foreground mt-0.5 shrink-0" />
                    <div>
                      <p className="text-xs font-medium text-muted-foreground mb-0.5">Responsável</p>
                      <p className="text-sm font-semibold text-foreground">{student.parentName}</p>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <Phone className="w-4 h-4 text-muted-foreground mt-0.5 shrink-0" />
                    <div>
                      <p className="text-xs font-medium text-muted-foreground mb-0.5">Contato</p>
                      <p className="text-sm font-semibold text-foreground">{student.parentPhone}</p>
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="flex items-start gap-3">
                      <School className="w-4 h-4 text-muted-foreground mt-0.5 shrink-0" />
                      <div>
                        <p className="text-xs font-medium text-muted-foreground mb-0.5">Horário</p>
                        <p className="text-sm font-semibold text-foreground">{student.scheduleName}</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <Clock className="w-4 h-4 text-muted-foreground mt-0.5 shrink-0" />
                      <div>
                        <p className="text-xs font-medium text-muted-foreground mb-0.5">Retirada</p>
                        <p className="text-sm font-semibold text-foreground">{student.departureTime}</p>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-start gap-3">
                    <MapPin className="w-4 h-4 text-muted-foreground mt-0.5 shrink-0" />
                    <div>
                      <p className="text-xs font-medium text-muted-foreground mb-0.5">Aulas Especiais</p>
                      <p className="text-sm font-semibold text-foreground">{student.destinationClass}</p>
                    </div>
                  </div>
                  {student.medicalNotes && (
                    <div className="flex items-start gap-3 bg-destructive/10 p-3 rounded-lg">
                      <FileText className="w-4 h-4 text-destructive mt-0.5 shrink-0" />
                      <div>
                        <p className="text-xs font-bold text-destructive mb-0.5">Observações Médicas</p>
                        <p className="text-sm font-medium text-foreground">{student.medicalNotes}</p>
                      </div>
                    </div>
                  )}
                </div>
              </div>

              <DrawerFooter className="pt-2 pb-6">
                <DrawerClose asChild>
                  <Button variant="outline" className="w-full font-bold shadow-sm">
                    Fechar
                  </Button>
                </DrawerClose>
              </DrawerFooter>
            </>
          )}
        </div>
      </DrawerContent>
    </Drawer>
  );
}
