import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider, useAuth } from "@/hooks/use-auth";
import { AppSettingsProvider } from "@/hooks/use-theme";
import { useOffline } from "@/hooks/use-offline";
import { OfflineBanner } from "@/components/offline-banner";
import NotFound from "@/pages/not-found";
import ScheduleList from "@/pages/schedule-list";
import ScheduleDetail from "@/pages/schedule-detail";
import ActivityLog from "@/pages/activity-log";
import Dashboard from "@/pages/dashboard";
import Settings from "@/pages/settings";
import LoginPage from "@/pages/login";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 1,
      refetchOnWindowFocus: false,
      staleTime: 30_000,
    },
  },
});

function AppShell() {
  const { monitor, isLoading } = useAuth();
  const { isOffline } = useOffline();

  if (isLoading) {
    return (
      <div className="min-h-[100dvh] bg-background flex items-center justify-center">
        <div className="w-8 h-8 rounded-full border-4 border-primary border-t-transparent animate-spin" />
      </div>
    );
  }

  if (!monitor) return <LoginPage />;

  return (
    <div className="flex flex-col min-h-[100dvh]">
      <OfflineBanner isOffline={isOffline} />
      <div className="flex-1">
        <Switch>
          <Route path="/" component={ScheduleList} />
          <Route path="/schedule/:scheduleId" component={ScheduleDetail} />
          <Route path="/activity-log" component={ActivityLog} />
          <Route path="/dashboard" component={Dashboard} />
          <Route path="/settings" component={Settings} />
          <Route component={NotFound} />
        </Switch>
      </div>
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <AppSettingsProvider>
          <AuthProvider>
            <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
              <AppShell />
            </WouterRouter>
            <Toaster />
          </AuthProvider>
        </AppSettingsProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
