import { useState } from "react";
import { Link } from "wouter";
import { ChevronLeft, Sun, Moon, Monitor, Bell, BellOff, ImageIcon, Trash2, CheckCircle2 } from "lucide-react";
import { useAppSettings } from "@/hooks/use-theme";
import { requestNotificationPermission } from "@/hooks/use-schedule-alerts";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import type { Theme } from "@/hooks/use-theme";

const THEME_OPTIONS: { value: Theme; label: string; icon: React.ElementType }[] = [
  { value: "light", label: "Claro", icon: Sun },
  { value: "dark", label: "Escuro", icon: Moon },
  { value: "system", label: "Sistema", icon: Monitor },
];

function getNotifPermission() {
  if (!("Notification" in window)) return "not-supported";
  return Notification.permission;
}

export default function Settings() {
  const { theme, setTheme, logoUrl, setLogoUrl } = useAppSettings();
  const [logoInput, setLogoInput] = useState(logoUrl);
  const [logoSaved, setLogoSaved] = useState(false);
  const [notifPerm, setNotifPerm] = useState(getNotifPermission);

  const saveLogo = () => {
    setLogoUrl(logoInput.trim());
    setLogoSaved(true);
    setTimeout(() => setLogoSaved(false), 2000);
  };

  const handleNotificationRequest = async () => {
    requestNotificationPermission();
    await Notification.requestPermission();
    setNotifPerm(getNotifPermission());
  };

  const handleLogoFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      const result = ev.target?.result as string;
      setLogoInput(result);
    };
    reader.readAsDataURL(file);
  };

  return (
    <div className="min-h-[100dvh] bg-background flex flex-col">
      <header className="bg-card border-b border-border shadow-sm sticky top-0 z-10">
        <div className="p-4 flex items-center gap-3 max-w-2xl mx-auto w-full">
          <Link href="/">
            <button className="p-2 -ml-2 rounded-full hover:bg-secondary active:scale-95 transition-all text-foreground">
              <ChevronLeft className="w-6 h-6" />
            </button>
          </Link>
          <h1 className="text-xl font-extrabold tracking-tight text-foreground">Configurações</h1>
        </div>
      </header>

      <main className="flex-1 max-w-2xl mx-auto w-full p-4 space-y-6 pb-10">
        {/* Appearance */}
        <section className="space-y-3">
          <p className="text-xs font-bold uppercase tracking-wider text-muted-foreground px-1">
            Aparência
          </p>
          <div className="bg-card border-2 border-border rounded-xl p-4 space-y-4">
            <p className="text-sm font-semibold text-foreground">Tema</p>
            <div className="grid grid-cols-3 gap-2">
              {THEME_OPTIONS.map(({ value, label, icon: Icon }) => (
                <button
                  key={value}
                  onClick={() => setTheme(value)}
                  className={cn(
                    "flex flex-col items-center gap-2 py-3 rounded-xl border-2 font-bold text-sm transition-all active:scale-95",
                    theme === value
                      ? "border-primary bg-primary/10 text-primary"
                      : "border-border text-muted-foreground hover:bg-secondary"
                  )}
                >
                  <Icon className="w-5 h-5" />
                  {label}
                </button>
              ))}
            </div>
          </div>
        </section>

        {/* School Logo */}
        <section className="space-y-3">
          <p className="text-xs font-bold uppercase tracking-wider text-muted-foreground px-1">
            Logo da Escola
          </p>
          <div className="bg-card border-2 border-border rounded-xl p-4 space-y-4">
            {logoInput && (
              <div className="flex items-center gap-4">
                <img
                  src={logoInput}
                  alt="Logo"
                  className="w-16 h-16 object-contain rounded-lg border border-border bg-secondary"
                  onError={(e) => {
                    (e.target as HTMLImageElement).style.display = "none";
                  }}
                />
                <div className="flex-1">
                  <p className="text-sm font-semibold text-foreground">Pré-visualização</p>
                  <p className="text-xs text-muted-foreground mt-0.5">Aparece no cabeçalho do app</p>
                </div>
                <button
                  onClick={() => { setLogoInput(""); setLogoUrl(""); }}
                  className="p-2 rounded-lg hover:bg-destructive/10 text-destructive transition-colors"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            )}

            <div className="space-y-2">
              <label className="text-xs font-bold uppercase tracking-wider text-muted-foreground block">
                URL da Imagem
              </label>
              <input
                type="url"
                value={logoInput.startsWith("data:") ? "" : logoInput}
                onChange={(e) => setLogoInput(e.target.value)}
                placeholder="https://exemplo.com/logo.png"
                className="w-full h-10 px-3 rounded-lg border-2 border-border bg-background text-foreground text-sm font-medium focus:outline-none focus:border-primary transition-colors placeholder:text-muted-foreground"
              />
            </div>

            <div className="flex items-center gap-2">
              <label className="flex-1">
                <div className="flex items-center justify-center gap-2 h-10 rounded-lg border-2 border-dashed border-border text-muted-foreground hover:border-primary hover:text-primary cursor-pointer text-sm font-semibold transition-colors">
                  <ImageIcon className="w-4 h-4" />
                  Escolher arquivo
                </div>
                <input
                  type="file"
                  accept="image/*"
                  className="hidden"
                  onChange={handleLogoFile}
                />
              </label>
              <Button onClick={saveLogo} className="shrink-0 font-bold" size="sm">
                {logoSaved ? (
                  <>
                    <CheckCircle2 className="w-4 h-4 mr-1" />
                    Salvo!
                  </>
                ) : (
                  "Salvar"
                )}
              </Button>
            </div>
          </div>
        </section>

        {/* Notifications */}
        <section className="space-y-3">
          <p className="text-xs font-bold uppercase tracking-wider text-muted-foreground px-1">
            Notificações
          </p>
          <div className="bg-card border-2 border-border rounded-xl p-4 space-y-3">
            <div className="flex items-start gap-3">
              {notifPerm === "granted" ? (
                <Bell className="w-5 h-5 text-success mt-0.5 shrink-0" />
              ) : (
                <BellOff className="w-5 h-5 text-muted-foreground mt-0.5 shrink-0" />
              )}
              <div className="flex-1">
                <p className="text-sm font-semibold text-foreground">
                  Notificações do sistema
                </p>
                <p className="text-xs text-muted-foreground mt-0.5">
                  {notifPerm === "granted"
                    ? "Ativadas — você receberá alertas de horário"
                    : notifPerm === "denied"
                    ? "Bloqueadas — ative nas configurações do navegador"
                    : notifPerm === "not-supported"
                    ? "Não suportado neste dispositivo"
                    : "Toque para ativar alertas de horário"}
                </p>
              </div>
              {notifPerm === "default" && (
                <Button
                  size="sm"
                  variant="outline"
                  className="shrink-0 font-bold"
                  onClick={handleNotificationRequest}
                >
                  Ativar
                </Button>
              )}
              {notifPerm === "granted" && (
                <span className="shrink-0 text-xs font-bold text-success px-2 py-1 rounded-full bg-success/10 border border-success/20">
                  Ativo
                </span>
              )}
            </div>
            <div className="text-xs text-muted-foreground bg-muted/50 rounded-lg p-3 space-y-1">
              <p className="font-semibold">Alertas automáticos:</p>
              <p>• Som suave 5 minutos antes da retirada</p>
              <p>• Alerta sonoro e vibração na hora da saída</p>
              <p>• Banner vermelho com alunos pendentes</p>
            </div>
          </div>
        </section>

        {/* Offline */}
        <section className="space-y-3">
          <p className="text-xs font-bold uppercase tracking-wider text-muted-foreground px-1">
            Modo Offline
          </p>
          <div className="bg-card border-2 border-border rounded-xl p-4">
            <p className="text-sm font-semibold text-foreground">Funcionamento sem internet</p>
            <p className="text-xs text-muted-foreground mt-1.5 leading-relaxed">
              O app continua funcionando offline usando dados em cache. Quando a conexão for
              restaurada, os dados são sincronizados automaticamente.
            </p>
          </div>
        </section>

        {/* About */}
        <section className="space-y-3">
          <p className="text-xs font-bold uppercase tracking-wider text-muted-foreground px-1">
            Sobre
          </p>
          <div className="bg-card border-2 border-border rounded-xl p-4 text-sm space-y-1">
            <p className="font-bold text-foreground">Monitor Escolar</p>
            <p className="text-muted-foreground">Gestão de transporte para Aulas Especiais</p>
            <p className="text-muted-foreground text-xs mt-2">Versão 1.0</p>
          </div>
        </section>
      </main>
    </div>
  );
}
