import { useState } from "react";
import { useParams, Link, useLocation } from "wouter";
import { useQueryClient } from "@tanstack/react-query";
import {
  useListScheduleStudents,
  getListScheduleStudentsQueryKey,
  useUpdateStudentStatus,
  useGetSchedulesSummary,
  useFinalizeSchedule,
} from "@workspace/api-client-react";
import { StudentCard } from "@/components/student-card";
import { StudentDrawer } from "@/components/student-drawer";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import {
  ChevronLeft,
  Users,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  ClipboardCheck,
  Clock,
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

function parseMinutes(time: string): number {
  const [h, m] = time.split(":").map(Number);
  return (h ?? 0) * 60 + (m ?? 0);
}

export default function ScheduleDetail() {
  const { scheduleId } = useParams();
  const id = Number(scheduleId);
  const queryClient = useQueryClient();
  const [, navigate] = useLocation();
  const { toast } = useToast();

  const [drawerOpen, setDrawerOpen] = useState(false);
  const [selectedStudentId, setSelectedStudentId] = useState<number | null>(null);

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const { data: students, isLoading: isLoadingStudents } = useListScheduleStudents(id, {
    query: { enabled: !!id } as any,
  });

  const { data: summaries } = useGetSchedulesSummary();
  const summary = summaries?.find((s) => s.scheduleId === id);

  const updateStatus = useUpdateStudentStatus();
  const { mutate: finalizeSchedule, isPending: isFinalizing } = useFinalizeSchedule();

  const now = new Date();
  const currentMinutes = now.getHours() * 60 + now.getMinutes();
  const depMinutes = summary ? parseMinutes(summary.departureTime) : null;
  const isOverdue =
    depMinutes !== null &&
    currentMinutes >= depMinutes &&
    (summary?.pendingCount ?? 0) > 0 &&
    !summary?.isFinalized;

  // Count students by status
  const pendingCount = students?.filter((s) => s.status === "unset").length ?? 0;
  const presentCount = students?.filter((s) => s.status === "present").length ?? 0;
  const absentCount = students?.filter((s) => s.status === "absent").length ?? 0;
  const collectedCount = students?.filter((s) => s.status === "collected").length ?? 0;
  const doneCount = presentCount + collectedCount;

  const isFinalized = summary?.isFinalized ?? false;

  // Tap a card: toggles between present ↔ unset
  // (absent and collected are set only via the drawer)
  const handleToggleStatus = (studentId: number, currentStatus: string) => {
    const newStatus = currentStatus === "present" ? "unset" : "present";
    const queryKey = getListScheduleStudentsQueryKey(id);
    queryClient.cancelQueries({ queryKey });
    const previousStudents = queryClient.getQueryData(queryKey);

    queryClient.setQueryData(queryKey, (old: unknown) => {
      if (!old || !Array.isArray(old)) return old;
      return old.map((s) =>
        s.id === studentId ? { ...s, status: newStatus } : s
      );
    });

    updateStatus.mutate(
      { studentId, data: { status: newStatus as "present" | "unset", scheduleId: id } },
      {
        onError: () => queryClient.setQueryData(queryKey, previousStudents),
        onSettled: () => {
          queryClient.invalidateQueries({ queryKey });
          queryClient.invalidateQueries({ queryKey: ["/api/schedules/summary"] });
        },
      }
    );
  };

  // Drawer action: "Aluno faltou" or "Pai retirou"
  const handleStatusChangeFromDrawer = (studentId: number, newStatus: string) => {
    const queryKey = getListScheduleStudentsQueryKey(id);
    queryClient.setQueryData(queryKey, (old: unknown) => {
      if (!old || !Array.isArray(old)) return old;
      return (old as Array<{ id: number }>).map((s) =>
        s.id === studentId ? { ...s, status: newStatus } : s
      );
    });
    queryClient.invalidateQueries({ queryKey });
    queryClient.invalidateQueries({ queryKey: ["/api/schedules/summary"] });
  };

  const handleLongPress = (studentId: number) => {
    setSelectedStudentId(studentId);
    setDrawerOpen(true);
  };

  const handleFinalize = () => {
    finalizeSchedule(
      { scheduleId: id },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: ["/api/schedules/summary"] });
          toast({
            title: "Horário concluído!",
            description: `${summary?.scheduleName} foi registrado com sucesso.`,
          });
          setTimeout(() => navigate("/"), 1200);
        },
        onError: (err: unknown) => {
          const msg =
            err instanceof Error ? err.message : "Erro ao finalizar horário.";
          toast({ title: "Erro", description: msg, variant: "destructive" });
        },
      }
    );
  };

  const selectedStudent = students?.find((s) => s.id === selectedStudentId);

  return (
    <div className="min-h-[100dvh] bg-background flex flex-col pb-28">
      {/* Header */}
      <header className="bg-card border-b border-border shadow-sm sticky top-0 z-10">
        <div className="p-4 flex items-center justify-between max-w-4xl mx-auto w-full">
          <div className="flex items-center gap-3 min-w-0">
            <Link href="/">
              <button className="p-2 -ml-2 rounded-full hover:bg-secondary active:scale-95 transition-all text-foreground shrink-0">
                <ChevronLeft className="w-6 h-6" />
              </button>
            </Link>
            <div className="min-w-0">
              <h1 className="text-xl font-extrabold tracking-tight text-foreground truncate max-w-[180px] sm:max-w-xs md:max-w-sm">
                {summary?.scheduleName ?? "Carregando..."}
              </h1>
              <p className="text-sm font-semibold text-muted-foreground mt-0.5 flex items-center gap-1">
                <Clock className="w-3.5 h-3.5" />
                Retirada: {summary?.departureTime ?? "--:--"}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            {isFinalized ? (
              <span className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-success/10 text-success border border-success/20 font-bold text-sm">
                <CheckCircle2 className="w-4 h-4" />
                Concluído
              </span>
            ) : (
              <>
                <div className="flex items-center gap-1 px-2 py-1 rounded-md bg-success/10 text-success border border-success/20 font-bold text-sm">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>{doneCount}</span>
                </div>
                {absentCount > 0 && (
                  <div className="flex items-center gap-1 px-2 py-1 rounded-md bg-destructive/10 text-destructive border border-destructive/20 font-bold text-sm">
                    <XCircle className="w-3.5 h-3.5" />
                    <span>{absentCount}</span>
                  </div>
                )}
                {pendingCount > 0 && (
                  <div className="flex items-center gap-1 px-2 py-1 rounded-md bg-amber-500/10 text-amber-600 border border-amber-500/20 font-bold text-sm">
                    <Users className="w-3.5 h-3.5" />
                    <span>{pendingCount}</span>
                  </div>
                )}
              </>
            )}
          </div>
        </div>
      </header>

      {/* Overdue warning (only when past time and still pending) */}
      {isOverdue && (
        <div className="bg-destructive/10 border-b border-destructive/20 max-w-4xl mx-auto w-full">
          <div className="px-4 py-2.5 flex items-center gap-2 text-destructive">
            <AlertTriangle className="w-4 h-4 shrink-0" />
            <p className="text-sm font-bold">
              Horário de saída passou — {pendingCount} aluno{pendingCount !== 1 ? "s" : ""} sem registro
            </p>
          </div>
        </div>
      )}

      {/* Instruction hint */}
      {!isFinalized && students && students.length > 0 && (
        <div className="max-w-4xl mx-auto w-full px-4 pt-3 pb-1">
          <p className="text-xs text-muted-foreground font-medium">
            Toque para marcar presença · Segure para registrar falta ou retirada pelo pai
          </p>
        </div>
      )}

      {/* Student grid */}
      <main className="flex-1 max-w-4xl mx-auto w-full px-4 py-3">
        {isLoadingStudents ? (
          <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 gap-3">
            {Array.from({ length: 12 }).map((_, i) => (
              <Skeleton key={i} className="h-[130px] w-full rounded-xl" />
            ))}
          </div>
        ) : students && students.length > 0 ? (
          <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 gap-3">
            {students.map((student) => (
              <StudentCard
                key={student.id}
                student={student}
                onToggleStatus={handleToggleStatus}
                onLongPress={handleLongPress}
                overdue={isOverdue && student.status === "unset"}
              />
            ))}
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center h-64 text-center px-4">
            <div className="bg-secondary rounded-full p-4 mb-4">
              <Users className="w-8 h-8 text-muted-foreground" />
            </div>
            <h2 className="text-xl font-bold text-foreground mb-2">Nenhum Aluno Encontrado</h2>
            <p className="text-muted-foreground font-medium max-w-xs">
              Não há alunos cadastrados neste horário.
            </p>
          </div>
        )}
      </main>

      {/* Sticky finalize button */}
      {students && students.length > 0 && (
        <div className="fixed bottom-0 left-0 right-0 bg-background/95 backdrop-blur-sm border-t border-border px-4 py-4 safe-b z-20">
          <div className="max-w-4xl mx-auto">
            {isFinalized ? (
              <div className="flex items-center justify-center gap-2.5 h-14 rounded-xl bg-success/10 border-2 border-success/30 text-success font-bold text-base">
                <CheckCircle2 className="w-5 h-5" />
                Horário Concluído
              </div>
            ) : (
              <Button
                className={cn(
                  "w-full h-14 text-base font-bold gap-2 shadow-lg",
                  pendingCount === 0
                    ? "bg-success hover:bg-success/90 text-success-foreground"
                    : ""
                )}
                variant={pendingCount === 0 ? "default" : "outline"}
                disabled={pendingCount > 0 || isFinalizing}
                onClick={handleFinalize}
              >
                <ClipboardCheck className="w-5 h-5 shrink-0" />
                {isFinalizing
                  ? "Registrando..."
                  : pendingCount > 0
                  ? `${pendingCount} aluno${pendingCount !== 1 ? "s" : ""} sem registro`
                  : "Registrar alunos do horário"}
              </Button>
            )}
          </div>
        </div>
      )}

      <StudentDrawer
        studentId={selectedStudentId}
        currentStatus={selectedStudent?.status}
        open={drawerOpen}
        onOpenChange={setDrawerOpen}
        onStatusChange={handleStatusChangeFromDrawer}
      />
    </div>
  );
}
