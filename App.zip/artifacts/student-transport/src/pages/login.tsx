import { useState, useEffect } from "react";
import { useAuth } from "@/hooks/use-auth";
import { cn } from "@/lib/utils";
import { Delete, LogIn } from "lucide-react";

interface MonitorItem {
  id: number;
  name: string;
}

export default function LoginPage() {
  const { login } = useAuth();
  const [monitors, setMonitors] = useState<MonitorItem[]>([]);
  const [selectedMonitor, setSelectedMonitor] = useState<MonitorItem | null>(null);
  const [pin, setPin] = useState("");
  const [error, setError] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    fetch("/api/auth/monitors", { credentials: "include" })
      .then((r) => r.json())
      .then(setMonitors)
      .catch(() => {});
  }, []);

  const handleDigit = (d: string) => {
    if (pin.length >= 4) return;
    setError("");
    setPin((p) => p + d);
  };

  const handleDelete = () => {
    setError("");
    setPin((p) => p.slice(0, -1));
  };

  const handleSubmit = async () => {
    if (!selectedMonitor || pin.length !== 4) return;
    setIsSubmitting(true);
    setError("");
    const result = await login(selectedMonitor.id, pin);
    setIsSubmitting(false);
    if (result.error) {
      setError(result.error);
      setPin("");
    }
  };

  const digits = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "", "0", "del"];

  return (
    <div className="min-h-[100dvh] bg-background flex flex-col items-center justify-start">
      <header className="w-full bg-card border-b border-border shadow-sm">
        <div className="max-w-md mx-auto p-4 px-6">
          <h1 className="text-2xl font-extrabold tracking-tight text-foreground">Monitor</h1>
          <p className="text-sm font-medium text-muted-foreground mt-0.5">Aulas Especiais</p>
        </div>
      </header>

      <main className="w-full max-w-sm mx-auto px-6 pt-8 flex flex-col gap-6">
        {/* Monitor selection */}
        <div>
          <p className="text-sm font-bold uppercase tracking-wider text-muted-foreground mb-3">
            Selecione o Monitor
          </p>
          <div className="flex flex-col gap-2">
            {monitors.map((m) => (
              <button
                key={m.id}
                onClick={() => {
                  setSelectedMonitor(m);
                  setPin("");
                  setError("");
                }}
                className={cn(
                  "w-full text-left px-4 py-3.5 rounded-xl border-2 font-semibold text-base transition-all active:scale-[0.98]",
                  selectedMonitor?.id === m.id
                    ? "border-primary bg-primary/10 text-primary"
                    : "border-border bg-card text-foreground hover:border-primary/50"
                )}
              >
                {m.name}
              </button>
            ))}
          </div>
        </div>

        {/* PIN entry */}
        {selectedMonitor && (
          <div className="flex flex-col items-center gap-5">
            <p className="text-sm font-bold uppercase tracking-wider text-muted-foreground">
              Digite o PIN
            </p>

            {/* PIN dots */}
            <div className="flex gap-4">
              {[0, 1, 2, 3].map((i) => (
                <div
                  key={i}
                  className={cn(
                    "w-4 h-4 rounded-full border-2 transition-all",
                    i < pin.length
                      ? "bg-primary border-primary scale-110"
                      : "bg-transparent border-muted-foreground/40"
                  )}
                />
              ))}
            </div>

            {/* Error message */}
            {error && (
              <p className="text-sm font-semibold text-destructive text-center">{error}</p>
            )}

            {/* Numpad */}
            <div className="grid grid-cols-3 gap-3 w-full">
              {digits.map((d, i) => {
                if (d === "") return <div key={i} />;
                if (d === "del") {
                  return (
                    <button
                      key={i}
                      onClick={handleDelete}
                      className="h-16 rounded-xl bg-card border-2 border-border flex items-center justify-center text-muted-foreground hover:bg-secondary active:scale-95 transition-all"
                    >
                      <Delete className="w-5 h-5" />
                    </button>
                  );
                }
                return (
                  <button
                    key={i}
                    onClick={() => handleDigit(d)}
                    className="h-16 rounded-xl bg-card border-2 border-border text-2xl font-bold text-foreground hover:bg-secondary active:scale-95 transition-all"
                  >
                    {d}
                  </button>
                );
              })}
            </div>

            {/* Enter button */}
            <button
              onClick={handleSubmit}
              disabled={pin.length !== 4 || isSubmitting}
              className={cn(
                "w-full h-14 rounded-xl font-bold text-base flex items-center justify-center gap-2 transition-all",
                pin.length === 4 && !isSubmitting
                  ? "bg-primary text-primary-foreground hover:opacity-90 active:scale-[0.98]"
                  : "bg-muted text-muted-foreground cursor-not-allowed"
              )}
            >
              <LogIn className="w-5 h-5" />
              {isSubmitting ? "Entrando..." : "Entrar"}
            </button>
          </div>
        )}
      </main>
    </div>
  );
}
