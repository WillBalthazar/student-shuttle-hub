import { useState } from "react";
import { Link } from "wouter";
import { useGetSchedulesSummary, useListSchedules } from "@workspace/api-client-react";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Clock,
  ArrowRight,
  LogOut,
  ClipboardList,
  LayoutDashboard,
  Settings,
  AlertTriangle,
  CalendarDays,
  CheckCircle2,
} from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { useAuth } from "@/hooks/use-auth";
import { useAppSettings } from "@/hooks/use-theme";
import { useScheduleAlerts } from "@/hooks/use-schedule-alerts";
import { PendingWarningBanner } from "@/components/pending-warning-banner";
import { cn } from "@/lib/utils";

type DayOfWeek = "segunda" | "terca" | "quarta" | "quinta" | "sexta";

const DAYS: { key: DayOfWeek; label: string; short: string }[] = [
  { key: "segunda", label: "Segunda-feira", short: "Seg" },
  { key: "terca",   label: "Terça-feira",   short: "Ter" },
  { key: "quarta",  label: "Quarta-feira",  short: "Qua" },
  { key: "quinta",  label: "Quinta-feira",  short: "Qui" },
  { key: "sexta",   label: "Sexta-feira",   short: "Sex" },
];

function getTodayDayOfWeek(): DayOfWeek {
  const day = new Date().getDay();
  const map: Record<number, DayOfWeek> = {
    1: "segunda",
    2: "terca",
    3: "quarta",
    4: "quinta",
    5: "sexta",
  };
  return map[day] ?? "segunda";
}

function parseMinutes(time: string): number {
  const [h, m] = time.split(":").map(Number);
  return (h ?? 0) * 60 + (m ?? 0);
}

export default function ScheduleList() {
  const { monitor, logout } = useAuth();
  const { logoUrl } = useAppSettings();

  const [selectedDay, setSelectedDay] = useState<DayOfWeek>(getTodayDayOfWeek);

  const { data: summaries, isLoading } = useGetSchedulesSummary();
  const { data: schedules } = useListSchedules();

  const todayKey = getTodayDayOfWeek();
  const todaySchedules = schedules?.filter((s) => s.dayOfWeek === todayKey);
  const todaySummaries = summaries?.filter((s) => s.dayOfWeek === todayKey);
  const overdueSchedules = useScheduleAlerts(todaySchedules, todaySummaries);

  const daySummaries = summaries?.filter((s) => s.dayOfWeek === selectedDay) ?? [];

  const now = new Date();
  const currentMinutes = now.getHours() * 60 + now.getMinutes();
  const isToday = selectedDay === todayKey;

  return (
    <div className="min-h-[100dvh] bg-background flex flex-col">
      {/* Header */}
      <header className="bg-card border-b border-border shadow-sm sticky top-0 z-20">
        <div className="max-w-2xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3 min-w-0">
            {logoUrl && (
              <img
                src={logoUrl}
                alt="Logo"
                className="w-9 h-9 object-contain rounded-lg shrink-0"
                onError={(e) => {
                  (e.target as HTMLImageElement).style.display = "none";
                }}
              />
            )}
            <div className="min-w-0">
              <h1 className="text-xl font-extrabold tracking-tight text-foreground truncate">
                Monitor
              </h1>
              <p className="text-sm font-medium text-muted-foreground truncate">
                {monitor?.name ?? "Horários"}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-0.5 shrink-0">
            <Link href="/dashboard">
              <button className="p-2 rounded-full hover:bg-secondary active:scale-95 transition-all text-muted-foreground hover:text-foreground" title="Painel">
                <LayoutDashboard className="w-5 h-5" />
              </button>
            </Link>
            <Link href="/activity-log">
              <button className="p-2 rounded-full hover:bg-secondary active:scale-95 transition-all text-muted-foreground hover:text-foreground" title="Registro">
                <ClipboardList className="w-5 h-5" />
              </button>
            </Link>
            <Link href="/settings">
              <button className="p-2 rounded-full hover:bg-secondary active:scale-95 transition-all text-muted-foreground hover:text-foreground" title="Configurações">
                <Settings className="w-5 h-5" />
              </button>
            </Link>
            <button
              onClick={logout}
              className="p-2 rounded-full hover:bg-secondary active:scale-95 transition-all text-muted-foreground hover:text-foreground"
              title="Sair"
            >
              <LogOut className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Day tabs */}
        <div className="max-w-2xl mx-auto -mx-0">
          <div className="flex border-b border-border px-4 gap-0 overflow-x-auto scrollbar-none">
            {DAYS.map((day) => {
              const hasOverdue =
                day.key === todayKey && overdueSchedules.length > 0;
              return (
                <button
                  key={day.key}
                  onClick={() => setSelectedDay(day.key)}
                  className={cn(
                    "relative flex-1 min-w-[52px] py-2.5 text-xs font-bold uppercase tracking-wide transition-all whitespace-nowrap",
                    selectedDay === day.key
                      ? "text-primary border-b-2 border-primary -mb-px"
                      : "text-muted-foreground hover:text-foreground"
                  )}
                >
                  <span className="hidden sm:inline">{day.label.split("-")[0]}</span>
                  <span className="sm:hidden">{day.short}</span>
                  {day.key === todayKey && (
                    <span
                      className={cn(
                        "absolute top-1.5 right-1 w-1.5 h-1.5 rounded-full",
                        hasOverdue ? "bg-destructive" : "bg-primary"
                      )}
                    />
                  )}
                </button>
              );
            })}
          </div>
        </div>
      </header>

      {/* Overdue banner (today only) */}
      {isToday && <PendingWarningBanner overdueSchedules={overdueSchedules} />}

      {/* Day label */}
      <div className="max-w-2xl mx-auto w-full px-4 pt-4 pb-1 flex items-center gap-2">
        <CalendarDays className="w-4 h-4 text-muted-foreground shrink-0" />
        <p className="text-sm font-bold text-foreground">
          {DAYS.find((d) => d.key === selectedDay)?.label}
        </p>
        {isToday && (
          <span className="text-[10px] font-bold uppercase tracking-wider text-primary bg-primary/10 px-2 py-0.5 rounded-full border border-primary/20">
            Hoje
          </span>
        )}
      </div>

      {/* Schedule cards */}
      <main className="flex-1 max-w-2xl mx-auto w-full px-4 pb-10 pt-2">
        <div className={cn("grid gap-4", daySummaries.length > 1 ? "md:grid-cols-2" : "grid-cols-1")}>
          {isLoading ? (
            Array.from({ length: 3 }).map((_, i) => (
              <Skeleton key={i} className="h-40 w-full rounded-xl" />
            ))
          ) : daySummaries.length > 0 ? (
            daySummaries.map((summary) => {
              const depMinutes = parseMinutes(summary.departureTime);
              const isOverdue =
                isToday &&
                currentMinutes >= depMinutes &&
                summary.pendingCount > 0 &&
                !summary.isFinalized;
              const isUpcoming =
                isToday &&
                !summary.isFinalized &&
                depMinutes - currentMinutes >= 0 &&
                depMinutes - currentMinutes <= 6;
              const doneCount = summary.presentCount + summary.collectedCount;

              return (
                <Link key={summary.scheduleId} href={`/schedule/${summary.scheduleId}`}>
                  <div
                    className={cn(
                      "group flex flex-col bg-card rounded-xl border-2 p-5 shadow-sm hover:border-primary active:scale-[0.98] transition-all cursor-pointer relative overflow-hidden",
                      summary.isFinalized
                        ? "border-success/40 bg-success/5"
                        : isOverdue
                        ? "border-destructive/60 bg-destructive/5"
                        : "border-border"
                    )}
                  >
                    {/* Title row */}
                    <div className="flex justify-between items-start mb-4 relative z-10">
                      <div className="min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <h2 className="text-xl font-bold text-foreground">
                            {summary.scheduleName}
                          </h2>
                          {summary.isFinalized && (
                            <span className="flex items-center gap-1 text-[10px] font-bold uppercase tracking-wider text-success bg-success/10 px-2 py-0.5 rounded-full border border-success/20 shrink-0">
                              <CheckCircle2 className="w-2.5 h-2.5" />
                              Concluído
                            </span>
                          )}
                          {isOverdue && !summary.isFinalized && (
                            <span className="flex items-center gap-1 text-[10px] font-bold uppercase tracking-wider text-destructive bg-destructive/10 px-2 py-0.5 rounded-full border border-destructive/20 shrink-0">
                              <AlertTriangle className="w-2.5 h-2.5" />
                              Pendente
                            </span>
                          )}
                          {isUpcoming && !isOverdue && !summary.isFinalized && (
                            <span className="text-[10px] font-bold uppercase tracking-wider text-amber-600 bg-amber-50 dark:bg-amber-950/30 px-2 py-0.5 rounded-full border border-amber-200 dark:border-amber-800 shrink-0">
                              Em breve
                            </span>
                          )}
                        </div>
                        <div className="flex items-center gap-1.5 text-muted-foreground mt-1">
                          <Clock className="w-4 h-4" />
                          <span className="font-semibold text-sm">
                            Retirada: {summary.departureTime}
                          </span>
                        </div>
                      </div>
                      <div
                        className={cn(
                          "rounded-full p-2 transition-colors shrink-0",
                          summary.isFinalized
                            ? "bg-success/10 text-success"
                            : isOverdue
                            ? "bg-destructive/10 text-destructive"
                            : "bg-secondary text-secondary-foreground group-hover:bg-primary group-hover:text-primary-foreground"
                        )}
                      >
                        {summary.isFinalized ? (
                          <CheckCircle2 className="w-5 h-5" />
                        ) : (
                          <ArrowRight className="w-5 h-5" />
                        )}
                      </div>
                    </div>

                    {/* Stat boxes */}
                    <div className="grid grid-cols-3 gap-2 relative z-10">
                      <div className="bg-background rounded-lg p-2.5 flex flex-col items-center border border-border">
                        <span className="text-2xl font-black text-foreground">
                          {summary.totalStudents}
                        </span>
                        <span className="text-[10px] uppercase font-bold text-muted-foreground mt-0.5">
                          Total
                        </span>
                      </div>
                      <div className="bg-success/10 rounded-lg p-2.5 flex flex-col items-center border border-success/20">
                        <span className="text-2xl font-black text-success">{doneCount}</span>
                        <span className="text-[10px] uppercase font-bold text-success mt-0.5">
                          OK
                        </span>
                      </div>
                      <div
                        className={cn(
                          "rounded-lg p-2.5 flex flex-col items-center border",
                          summary.pendingCount > 0
                            ? "bg-amber-500/10 border-amber-500/20"
                            : "bg-muted/50 border-border"
                        )}
                      >
                        <span
                          className={cn(
                            "text-2xl font-black",
                            summary.pendingCount > 0 ? "text-amber-600" : "text-muted-foreground"
                          )}
                        >
                          {summary.pendingCount}
                        </span>
                        <span
                          className={cn(
                            "text-[10px] uppercase font-bold mt-0.5",
                            summary.pendingCount > 0 ? "text-amber-600" : "text-muted-foreground"
                          )}
                        >
                          Pendente
                        </span>
                      </div>
                    </div>

                    {/* Absent info row */}
                    {summary.absentCount > 0 && (
                      <div className="mt-2 flex items-center gap-1.5 text-xs text-destructive font-semibold">
                        <span className="w-2 h-2 rounded-full bg-destructive inline-block" />
                        {summary.absentCount} faltou{summary.absentCount !== 1 ? "ram" : ""} (registrado)
                      </div>
                    )}
                    {summary.collectedCount > 0 && (
                      <div className="mt-1 flex items-center gap-1.5 text-xs text-sky-600 font-semibold">
                        <span className="w-2 h-2 rounded-full bg-sky-400 inline-block" />
                        {summary.collectedCount} retirado{summary.collectedCount !== 1 ? "s" : ""} pelo responsável
                      </div>
                    )}

                    {/* Progress bar */}
                    <div
                      className={cn(
                        "absolute bottom-0 left-0 h-1 transition-all duration-500",
                        summary.isFinalized ? "bg-success" : isOverdue ? "bg-destructive" : "bg-success"
                      )}
                      style={{
                        width:
                          summary.totalStudents > 0
                            ? `${(doneCount / summary.totalStudents) * 100}%`
                            : "0%",
                      }}
                    />
                  </div>
                </Link>
              );
            })
          ) : (
            <Alert>
              <CalendarDays className="w-4 h-4" />
              <AlertTitle>Nenhum horário</AlertTitle>
              <AlertDescription>
                Não há aulas especiais cadastradas para{" "}
                {DAYS.find((d) => d.key === selectedDay)?.label?.toLowerCase()}.
              </AlertDescription>
            </Alert>
          )}
        </div>
      </main>
    </div>
  );
}
