import { Link } from "wouter";
import { useGetDashboard, useGetSchedulesSummary } from "@workspace/api-client-react";
import {
  ChevronLeft,
  Users,
  CheckCircle2,
  XCircle,
  Clock,
  TrendingUp,
  AlertCircle,
  LayoutDashboard,
} from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { cn } from "@/lib/utils";

function StatCard({
  label,
  value,
  icon: Icon,
  colorClass,
  sub,
}: {
  label: string;
  value: number | undefined;
  icon: React.ElementType;
  colorClass: string;
  sub?: string;
}) {
  return (
    <div className={cn("flex flex-col gap-2 rounded-2xl border-2 p-4 shadow-sm", colorClass)}>
      <div className="flex items-center justify-between">
        <p className="text-[10px] font-bold uppercase tracking-wider opacity-70 leading-tight">{label}</p>
        <Icon className="w-4 h-4 opacity-60 shrink-0" />
      </div>
      {value === undefined ? (
        <Skeleton className="h-10 w-16" />
      ) : (
        <p className="text-4xl font-black leading-none">{value}</p>
      )}
      {sub && <p className="text-[10px] font-semibold opacity-60 leading-tight">{sub}</p>}
    </div>
  );
}

export default function Dashboard() {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const {
    data: stats,
    isLoading: statsLoading,
    refetch,
  } = useGetDashboard({ query: { refetchInterval: 20000 } as any });

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const { data: summaries } = useGetSchedulesSummary(undefined, {
    query: { refetchInterval: 20000 } as any,
  });

  const today = new Date().toLocaleDateString("pt-BR", {
    weekday: "long",
    day: "2-digit",
    month: "long",
  });

  return (
    <div className="min-h-[100dvh] bg-background flex flex-col">
      <header className="bg-card border-b border-border shadow-sm sticky top-0 z-10">
        <div className="p-4 flex items-center justify-between max-w-2xl mx-auto w-full">
          <div className="flex items-center gap-3">
            <Link href="/">
              <button className="p-2 -ml-2 rounded-full hover:bg-secondary active:scale-95 transition-all text-foreground">
                <ChevronLeft className="w-6 h-6" />
              </button>
            </Link>
            <div>
              <h1 className="text-xl font-extrabold tracking-tight text-foreground flex items-center gap-2">
                <LayoutDashboard className="w-5 h-5" />
                Painel Geral
              </h1>
              <p className="text-sm font-semibold text-muted-foreground capitalize mt-0.5">{today}</p>
            </div>
          </div>
          <button
            onClick={() => refetch()}
            className="text-xs font-bold px-3 py-1.5 rounded-lg bg-secondary text-secondary-foreground hover:opacity-80 active:scale-95 transition-all"
          >
            Atualizar
          </button>
        </div>
      </header>

      <main className="flex-1 max-w-2xl mx-auto w-full p-4 space-y-6 pb-10">
        {/* Summary cards */}
        <section>
          <p className="text-xs font-bold uppercase tracking-wider text-muted-foreground mb-3 px-1">
            Resumo do Dia
          </p>
          <div className="grid grid-cols-2 gap-3">
            <StatCard
              label="Total de Alunos"
              value={statsLoading ? undefined : stats?.totalStudents}
              icon={Users}
              colorClass="border-border text-foreground bg-card"
            />
            <StatCard
              label="Transportados Hoje"
              value={statsLoading ? undefined : stats?.totalTransported}
              icon={TrendingUp}
              colorClass="border-primary/30 text-primary bg-primary/5"
              sub="com alguma ação registrada"
            />
            <StatCard
              label="Presentes"
              value={statsLoading ? undefined : stats?.totalPresent}
              icon={CheckCircle2}
              colorClass="border-success/40 text-success bg-success/5"
            />
            <StatCard
              label="Ausentes"
              value={statsLoading ? undefined : stats?.totalAbsent}
              icon={XCircle}
              colorClass="border-destructive/40 text-destructive bg-destructive/5"
            />
            <StatCard
              label="Pendentes"
              value={statsLoading ? undefined : stats?.pendingStudents}
              icon={AlertCircle}
              colorClass="border-amber-400/40 text-amber-600 bg-amber-50"
              sub="sem ação registrada"
            />
            <StatCard
              label="Horários Concluídos"
              value={statsLoading ? undefined : stats?.completedSchedules}
              icon={Clock}
              colorClass="border-border text-foreground bg-card"
              sub={summaries ? `de ${summaries.length} no total` : undefined}
            />
          </div>
        </section>

        {/* Per-schedule breakdown */}
        <section>
          <p className="text-xs font-bold uppercase tracking-wider text-muted-foreground mb-3 px-1">
            Por Horário
          </p>
          <div className="space-y-3">
            {!summaries ? (
              Array.from({ length: 3 }).map((_, i) => (
                <Skeleton key={i} className="h-28 w-full rounded-xl" />
              ))
            ) : (
              summaries.map((s) => {
                const pct =
                  s.totalStudents > 0
                    ? Math.round((s.presentCount / s.totalStudents) * 100)
                    : 0;
                return (
                  <Link key={s.scheduleId} href={`/schedule/${s.scheduleId}`}>
                    <div className="bg-card rounded-xl border-2 border-border p-4 hover:border-primary active:scale-[0.98] transition-all cursor-pointer relative overflow-hidden">
                      <div className="flex items-start justify-between mb-2">
                        <div>
                          <p className="font-bold text-base text-foreground">{s.scheduleName}</p>
                          <div className="flex items-center gap-1.5 text-muted-foreground mt-0.5">
                            <Clock className="w-3.5 h-3.5" />
                            <span className="text-xs font-semibold">Retirada: {s.departureTime}</span>
                          </div>
                        </div>
                        <span
                          className={cn(
                            "text-xs font-bold px-2.5 py-1 rounded-full",
                            pct === 100
                              ? "bg-success/15 text-success"
                              : pct > 0
                              ? "bg-amber-100 text-amber-700"
                              : "bg-destructive/10 text-destructive"
                          )}
                        >
                          {pct}%
                        </span>
                      </div>
                      <div className="flex gap-4 text-xs mb-3">
                        <span className="font-semibold text-foreground">
                          {s.totalStudents} alunos
                        </span>
                        <span className="text-success font-bold">
                          {s.presentCount} presentes
                        </span>
                        <span className="text-destructive font-bold">
                          {s.absentCount} ausentes
                        </span>
                      </div>
                      <div className="h-1.5 bg-muted rounded-full overflow-hidden">
                        <div
                          className="h-full bg-success rounded-full transition-all duration-700"
                          style={{ width: `${pct}%` }}
                        />
                      </div>
                    </div>
                  </Link>
                );
              })
            )}
          </div>
        </section>
      </main>
    </div>
  );
}
