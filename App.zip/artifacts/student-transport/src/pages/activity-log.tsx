import { useState, useEffect } from "react";
import { Link } from "wouter";
import { useListActivityLogs, useListSchedules } from "@workspace/api-client-react";
import { ChevronLeft, ClipboardList, CheckCircle2, XCircle, Filter, Search, Truck, Package, RotateCcw, BadgeCheck } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { cn } from "@/lib/utils";

interface MonitorOption {
  id: number;
  name: string;
}

type ActionKey = "retirada" | "entrega" | "retorno" | "confirmacao";

const ACTION_CONFIG: Record<ActionKey, { label: string; icon: React.ElementType; color: string }> = {
  retirada: { label: "Retirada", icon: Truck, color: "bg-blue-50 text-blue-700 border-blue-200" },
  entrega: { label: "Entrega", icon: Package, color: "bg-amber-50 text-amber-700 border-amber-200" },
  retorno: { label: "Retorno", icon: RotateCcw, color: "bg-purple-50 text-purple-700 border-purple-200" },
  confirmacao: { label: "Confirmação", icon: BadgeCheck, color: "bg-success/10 text-success border-success/20" },
};

function todayISO(): string {
  return new Date().toISOString().slice(0, 10);
}

function formatTime(iso: string): string {
  return new Date(iso).toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" });
}

function formatDate(iso: string): string {
  return new Date(iso).toLocaleDateString("pt-BR", { day: "2-digit", month: "2-digit", year: "numeric" });
}

export default function ActivityLog() {
  const [date, setDate] = useState(todayISO());
  const [monitorId, setMonitorId] = useState<number | undefined>(undefined);
  const [scheduleId, setScheduleId] = useState<number | undefined>(undefined);
  const [studentName, setStudentName] = useState("");
  const [showFilters, setShowFilters] = useState(false);
  const [monitors, setMonitors] = useState<MonitorOption[]>([]);

  useEffect(() => {
    fetch("/api/auth/monitors", { credentials: "include" })
      .then((r) => r.json())
      .then(setMonitors)
      .catch(() => {});
  }, []);

  const { data: schedules } = useListSchedules();

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const { data: entries, isLoading } = useListActivityLogs(
    {
      date,
      monitorId,
      scheduleId,
      studentName: studentName.trim() || undefined,
    },
    { query: { refetchInterval: 15000 } as any }
  );

  const grouped = (entries ?? []).reduce<Record<string, typeof entries>>((acc, entry) => {
    const day = formatDate(entry.createdAt);
    if (!acc[day]) acc[day] = [];
    acc[day]!.push(entry);
    return acc;
  }, {});

  const activeFilters = [monitorId, scheduleId, studentName.trim()].filter(Boolean).length;

  const clearFilters = () => {
    setDate(todayISO());
    setMonitorId(undefined);
    setScheduleId(undefined);
    setStudentName("");
  };

  return (
    <div className="min-h-[100dvh] bg-background flex flex-col">
      <header className="bg-card border-b border-border shadow-sm sticky top-0 z-10">
        <div className="p-4 flex items-center justify-between max-w-2xl mx-auto w-full">
          <div className="flex items-center gap-3">
            <Link href="/">
              <button className="p-2 -ml-2 rounded-full hover:bg-secondary active:scale-95 transition-all text-foreground">
                <ChevronLeft className="w-6 h-6" />
              </button>
            </Link>
            <div>
              <h1 className="text-xl font-extrabold tracking-tight text-foreground">
                Registro de Atividades
              </h1>
              <p className="text-sm font-semibold text-muted-foreground mt-0.5">
                {entries ? `${entries.length} registro${entries.length !== 1 ? "s" : ""}` : "Carregando..."}
              </p>
            </div>
          </div>
          <button
            onClick={() => setShowFilters((v) => !v)}
            className={cn(
              "relative p-2 rounded-full transition-all active:scale-95",
              showFilters
                ? "bg-primary text-primary-foreground"
                : "hover:bg-secondary text-muted-foreground hover:text-foreground"
            )}
          >
            <Filter className="w-5 h-5" />
            {activeFilters > 0 && (
              <span className="absolute -top-0.5 -right-0.5 w-4 h-4 bg-destructive text-white text-[10px] font-bold rounded-full flex items-center justify-center">
                {activeFilters}
              </span>
            )}
          </button>
        </div>

        {/* Filters panel */}
        {showFilters && (
          <div className="border-t border-border bg-card/80 px-4 py-4 max-w-2xl mx-auto w-full space-y-3">
            {/* Row 1: date + monitor */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground block mb-1.5">
                  Data
                </label>
                <input
                  type="date"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="w-full h-10 px-3 rounded-lg border-2 border-border bg-background text-foreground font-semibold text-sm focus:outline-none focus:border-primary transition-colors"
                />
              </div>
              <div>
                <label className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground block mb-1.5">
                  Monitor
                </label>
                <select
                  value={monitorId ?? ""}
                  onChange={(e) => setMonitorId(e.target.value ? Number(e.target.value) : undefined)}
                  className="w-full h-10 px-3 rounded-lg border-2 border-border bg-background text-foreground font-semibold text-sm focus:outline-none focus:border-primary transition-colors"
                >
                  <option value="">Todos</option>
                  {monitors.map((m) => (
                    <option key={m.id} value={m.id}>{m.name}</option>
                  ))}
                </select>
              </div>
            </div>
            {/* Row 2: schedule + student name */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground block mb-1.5">
                  Horário
                </label>
                <select
                  value={scheduleId ?? ""}
                  onChange={(e) => setScheduleId(e.target.value ? Number(e.target.value) : undefined)}
                  className="w-full h-10 px-3 rounded-lg border-2 border-border bg-background text-foreground font-semibold text-sm focus:outline-none focus:border-primary transition-colors"
                >
                  <option value="">Todos</option>
                  {(schedules ?? []).map((s) => (
                    <option key={s.id} value={s.id}>{s.name}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground block mb-1.5">
                  Aluno
                </label>
                <div className="relative">
                  <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
                  <input
                    type="text"
                    value={studentName}
                    onChange={(e) => setStudentName(e.target.value)}
                    placeholder="Nome..."
                    className="w-full h-10 pl-8 pr-3 rounded-lg border-2 border-border bg-background text-foreground font-semibold text-sm focus:outline-none focus:border-primary transition-colors placeholder:font-normal placeholder:text-muted-foreground"
                  />
                </div>
              </div>
            </div>
            <button
              onClick={clearFilters}
              className="w-full h-9 rounded-lg border-2 border-border text-sm font-bold text-muted-foreground hover:bg-secondary transition-all"
            >
              Limpar filtros
            </button>
          </div>
        )}
      </header>

      <main className="flex-1 max-w-2xl mx-auto w-full p-4 space-y-6 pb-10">
        {isLoading ? (
          <div className="space-y-3 pt-2">
            {Array.from({ length: 6 }).map((_, i) => (
              <Skeleton key={i} className="h-24 w-full rounded-xl" />
            ))}
          </div>
        ) : Object.keys(grouped).length > 0 ? (
          Object.entries(grouped).map(([day, dayEntries]) => (
            <div key={day}>
              <p className="text-xs font-bold uppercase tracking-wider text-muted-foreground mb-2 px-1">
                {day}
              </p>
              <div className="space-y-2">
                {dayEntries!.map((entry) => {
                  const actionKey = entry.action as ActionKey;
                  const cfg = ACTION_CONFIG[actionKey] ?? ACTION_CONFIG.retirada;
                  const Icon = cfg.icon;
                  return (
                    <div
                      key={entry.id}
                      className="flex items-start gap-3 bg-card rounded-xl border-2 border-border p-4"
                    >
                      <div className={cn("mt-0.5 shrink-0 rounded-full p-1.5 border", cfg.color)}>
                        <Icon className="w-4 h-4" />
                      </div>

                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between gap-2">
                          <p className="font-bold text-sm text-foreground leading-tight">
                            {entry.studentName}
                          </p>
                          <div className="flex items-center gap-2 shrink-0">
                            <span className={cn(
                              "text-xs font-bold px-2 py-0.5 rounded-full border",
                              cfg.color
                            )}>
                              {cfg.label}
                            </span>
                            <span className="text-xs font-semibold text-muted-foreground whitespace-nowrap">
                              {formatTime(entry.createdAt)}
                            </span>
                          </div>
                        </div>

                        <div className="mt-1 flex flex-wrap gap-x-3 gap-y-0.5">
                          <span className="text-xs text-muted-foreground">
                            <span className="font-semibold text-foreground/60">Turma:</span> {entry.grade}
                          </span>
                          <span className="text-xs text-muted-foreground">
                            <span className="font-semibold text-foreground/60">Monitor:</span> {entry.monitorName}
                          </span>
                        </div>
                        <div className="mt-0.5 flex flex-wrap gap-x-3 gap-y-0.5">
                          <span className="text-xs text-muted-foreground">
                            <span className="font-semibold text-foreground/60">Horário:</span> {entry.scheduleName}
                          </span>
                          <span className="text-xs text-muted-foreground">
                            <span className="font-semibold text-foreground/60">Local:</span> {entry.destinationClass}
                          </span>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          ))
        ) : (
          <div className="flex flex-col items-center justify-center h-64 text-center px-4 pt-8">
            <div className="bg-secondary rounded-full p-4 mb-4">
              <ClipboardList className="w-8 h-8 text-muted-foreground" />
            </div>
            <h2 className="text-xl font-bold text-foreground mb-2">Nenhum registro encontrado</h2>
            <p className="text-muted-foreground font-medium max-w-xs">
              Nenhuma ação registrada com os filtros selecionados.
            </p>
          </div>
        )}
      </main>
    </div>
  );
}
