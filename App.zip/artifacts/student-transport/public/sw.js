const CACHE_NAME = "school-monitor-v1";

// On install: take control immediately
self.addEventListener("install", (event) => {
  event.waitUntil(caches.open(CACHE_NAME).then(() => self.skipWaiting()));
});

// On activate: clean up old caches
self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) =>
        Promise.all(
          keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k))
        )
      )
      .then(() => self.clients.claim())
  );
});

// Fetch strategy:
// - /api/* → network first, cache GET responses as fallback
// - everything else → cache first, network fallback, then cache
self.addEventListener("fetch", (event) => {
  const url = new URL(event.request.url);

  // Only handle same-origin or relative requests
  if (url.origin !== location.origin) return;

  if (url.pathname.startsWith("/api/")) {
    // Network-first for API calls (only cache GET)
    if (event.request.method !== "GET") return;
    event.respondWith(
      fetch(event.request.clone())
        .then((response) => {
          if (response.ok) {
            const clone = response.clone();
            caches.open(CACHE_NAME).then((cache) =>
              cache.put(event.request, clone)
            );
          }
          return response;
        })
        .catch(() =>
          caches.match(event.request).then((cached) => cached ?? Response.error())
        )
    );
    return;
  }

  // Cache-first for app shell (HTML, JS, CSS, fonts)
  event.respondWith(
    caches.match(event.request).then((cached) => {
      if (cached) {
        // Revalidate in background
        fetch(event.request.clone())
          .then((response) => {
            if (response.ok) {
              caches
                .open(CACHE_NAME)
                .then((cache) => cache.put(event.request, response));
            }
          })
          .catch(() => {});
        return cached;
      }

      return fetch(event.request.clone())
        .then((response) => {
          if (response.ok) {
            const clone = response.clone();
            caches.open(CACHE_NAME).then((cache) =>
              cache.put(event.request, clone)
            );
          }
          return response;
        })
        .catch(() => caches.match("/") ?? Response.error());
    })
  );
});
