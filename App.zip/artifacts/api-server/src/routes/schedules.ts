import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { db, schedulesTable, studentsTable, studentStatusesTable } from "@workspace/db";
import {
  ListSchedulesResponse,
  GetSchedulesSummaryResponse,
  ListScheduleStudentsParams,
  ListScheduleStudentsResponse,
  FinalizeScheduleParams,
  FinalizeScheduleResponse,
} from "@workspace/api-zod";

const VALID_DAYS = new Set(["segunda", "terca", "quarta", "quinta", "sexta"]);

function parseDayParam(raw: unknown): string | undefined {
  if (typeof raw === "string" && VALID_DAYS.has(raw)) return raw;
  return undefined;
}

const router: IRouter = Router();

router.get("/schedules", async (req, res): Promise<void> => {
  const day = parseDayParam(req.query.dayOfWeek);
  const schedules = day
    ? await db
        .select()
        .from(schedulesTable)
        .where(eq(schedulesTable.dayOfWeek, day))
        .orderBy(schedulesTable.departureTime)
    : await db
        .select()
        .from(schedulesTable)
        .orderBy(schedulesTable.departureTime);
  res.json(ListSchedulesResponse.parse(schedules));
});

router.get("/schedules/summary", async (req, res): Promise<void> => {
  const day = parseDayParam(req.query.dayOfWeek);
  const schedules = day
    ? await db
        .select()
        .from(schedulesTable)
        .where(eq(schedulesTable.dayOfWeek, day))
        .orderBy(schedulesTable.departureTime)
    : await db
        .select()
        .from(schedulesTable)
        .orderBy(schedulesTable.departureTime);

  const summaries = await Promise.all(
    schedules.map(async (schedule) => {
      const students = await db
        .select()
        .from(studentsTable)
        .where(eq(studentsTable.scheduleId, schedule.id));

      const totalStudents = students.length;

      const statuses = await db
        .select()
        .from(studentStatusesTable)
        .where(eq(studentStatusesTable.scheduleId, schedule.id));

      const presentCount = statuses.filter((s) => s.status === "present").length;
      const absentCount = statuses.filter((s) => s.status === "absent").length;
      const collectedCount = statuses.filter((s) => s.status === "collected").length;
      // Students with no record in student_statuses are pending (unset)
      const pendingCount = totalStudents - statuses.length;

      return {
        scheduleId: schedule.id,
        scheduleName: schedule.name,
        departureTime: schedule.departureTime,
        dayOfWeek: schedule.dayOfWeek,
        totalStudents,
        presentCount,
        absentCount,
        collectedCount,
        pendingCount,
        isFinalized: schedule.finalizedAt !== null,
      };
    })
  );

  res.json(GetSchedulesSummaryResponse.parse(summaries));
});

router.get("/schedules/:scheduleId/students", async (req, res): Promise<void> => {
  const params = ListScheduleStudentsParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const { scheduleId } = params.data;

  const students = await db
    .select()
    .from(studentsTable)
    .where(eq(studentsTable.scheduleId, scheduleId));

  if (students.length === 0) {
    res.json(ListScheduleStudentsResponse.parse([]));
    return;
  }

  const statuses = await db
    .select()
    .from(studentStatusesTable)
    .where(eq(studentStatusesTable.scheduleId, scheduleId));

  const statusMap = new Map(statuses.map((s) => [s.studentId, s.status]));

  const result = students.map((student) => ({
    id: student.id,
    name: student.name,
    grade: student.grade,
    photoUrl: student.photoUrl,
    // No record → "unset" (not yet registered by monitor)
    status: statusMap.get(student.id) ?? "unset",
    scheduleId: student.scheduleId,
  }));

  res.json(ListScheduleStudentsResponse.parse(result));
});

router.post("/schedules/:scheduleId/finalize", async (req, res): Promise<void> => {
  const params = FinalizeScheduleParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const { scheduleId } = params.data;

  const [schedule] = await db
    .select()
    .from(schedulesTable)
    .where(eq(schedulesTable.id, scheduleId));

  if (!schedule) {
    res.status(404).json({ error: "Schedule not found" });
    return;
  }

  // Ensure every student has an explicit status record
  const students = await db
    .select()
    .from(studentsTable)
    .where(eq(studentsTable.scheduleId, scheduleId));

  const statuses = await db
    .select()
    .from(studentStatusesTable)
    .where(eq(studentStatusesTable.scheduleId, scheduleId));

  const pendingCount = students.length - statuses.length;
  if (pendingCount > 0) {
    res.status(400).json({
      error: `Há ${pendingCount} aluno${pendingCount !== 1 ? "s" : ""} sem registro. Registre todos antes de finalizar.`,
    });
    return;
  }

  await db
    .update(schedulesTable)
    .set({ finalizedAt: new Date() })
    .where(eq(schedulesTable.id, scheduleId));

  const [updated] = await db
    .select()
    .from(schedulesTable)
    .where(eq(schedulesTable.id, scheduleId));

  res.json(FinalizeScheduleResponse.parse(updated));
});

export default router;
