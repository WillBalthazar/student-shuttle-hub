import { Router, type IRouter } from "express";
import healthRouter from "./health";
import authRouter from "./auth";
import schedulesRouter from "./schedules";
import studentsRouter from "./students";
import activityLogsRouter from "./activity-logs";
import dashboardRouter from "./dashboard";

const router: IRouter = Router();

router.use(healthRouter);
router.use(authRouter);
router.use(schedulesRouter);
router.use(studentsRouter);
router.use(activityLogsRouter);
router.use(dashboardRouter);

export default router;
