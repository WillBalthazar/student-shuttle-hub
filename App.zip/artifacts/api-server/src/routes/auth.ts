import { Router, type IRouter } from "express";
import bcrypt from "bcryptjs";
import { eq } from "drizzle-orm";
import { db, monitorsTable } from "@workspace/db";

const router: IRouter = Router();

router.get("/auth/monitors", async (_req, res): Promise<void> => {
  const monitors = await db
    .select({ id: monitorsTable.id, name: monitorsTable.name })
    .from(monitorsTable)
    .orderBy(monitorsTable.name);
  res.json(monitors);
});

router.get("/auth/me", async (req, res): Promise<void> => {
  const session = req.session as any;
  if (!session.monitorId) {
    res.status(401).json({ error: "Não autenticado" });
    return;
  }
  const [monitor] = await db
    .select({ id: monitorsTable.id, name: monitorsTable.name })
    .from(monitorsTable)
    .where(eq(monitorsTable.id, session.monitorId));

  if (!monitor) {
    session.destroy(() => {});
    res.status(401).json({ error: "Monitor não encontrado" });
    return;
  }
  res.json(monitor);
});

router.post("/auth/login", async (req, res): Promise<void> => {
  const { monitorId, pin } = req.body as { monitorId: number; pin: string };

  if (!monitorId || !pin) {
    res.status(400).json({ error: "Monitor e PIN obrigatórios" });
    return;
  }

  const [monitor] = await db
    .select()
    .from(monitorsTable)
    .where(eq(monitorsTable.id, Number(monitorId)));

  if (!monitor) {
    res.status(401).json({ error: "Monitor não encontrado" });
    return;
  }

  const valid = await bcrypt.compare(String(pin), monitor.pinHash);
  if (!valid) {
    req.log.warn({ monitorId }, "Failed PIN attempt");
    res.status(401).json({ error: "PIN incorreto" });
    return;
  }

  const session = req.session as any;
  session.monitorId = monitor.id;
  session.monitorName = monitor.name;

  req.log.info({ monitorId: monitor.id, name: monitor.name }, "Monitor logged in");
  res.json({ id: monitor.id, name: monitor.name });
});

router.post("/auth/logout", async (req, res): Promise<void> => {
  req.session.destroy(() => {
    res.json({ ok: true });
  });
});

export default router;
