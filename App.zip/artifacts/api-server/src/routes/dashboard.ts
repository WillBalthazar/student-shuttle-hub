import { Router, type IRouter } from "express";
import { eq, and, gte, lt, sql } from "drizzle-orm";
import { db, studentsTable, studentStatusesTable, activityLogsTable, schedulesTable } from "@workspace/db";

const router: IRouter = Router();

router.get("/dashboard", async (_req, res): Promise<void> => {
  const now = new Date();
  const todayStart = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate(), 0, 0, 0));
  const todayEnd = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate(), 23, 59, 59, 999));

  // Total students
  const [{ count: totalStudents }] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(studentsTable);

  // Present / Absent
  const [{ count: totalPresent }] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(studentStatusesTable)
    .where(eq(studentStatusesTable.status, "present"));

  const totalAbsent = totalStudents - totalPresent;

  // Pending: students with no status record (never toggled)
  const [{ count: withStatus }] = await db
    .select({ count: sql<number>`count(distinct student_id)::int` })
    .from(studentStatusesTable);

  const pendingStudents = totalStudents - withStatus;

  // Total transported today: distinct students with any activity log today
  const [{ count: totalTransported }] = await db
    .select({ count: sql<number>`count(distinct student_id)::int` })
    .from(activityLogsTable)
    .where(
      and(
        gte(activityLogsTable.createdAt, todayStart),
        lt(activityLogsTable.createdAt, todayEnd)
      )
    );

  // Completed schedules: schedules where all students have at least one log today
  const schedules = await db.select().from(schedulesTable);
  let completedSchedules = 0;

  for (const schedule of schedules) {
    const [{ total }] = await db
      .select({ total: sql<number>`count(*)::int` })
      .from(studentsTable)
      .where(eq(studentsTable.scheduleId, schedule.id));

    if (total === 0) continue;

    const [{ transported }] = await db
      .select({ transported: sql<number>`count(distinct student_id)::int` })
      .from(activityLogsTable)
      .where(
        and(
          eq(activityLogsTable.scheduleId, schedule.id),
          gte(activityLogsTable.createdAt, todayStart),
          lt(activityLogsTable.createdAt, todayEnd)
        )
      );

    if (transported >= total) completedSchedules++;
  }

  res.json({
    totalStudents,
    totalPresent,
    totalAbsent,
    pendingStudents,
    completedSchedules,
    totalTransported,
  });
});

export default router;
