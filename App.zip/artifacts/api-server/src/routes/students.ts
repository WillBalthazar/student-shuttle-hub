import { Router, type IRouter } from "express";
import { eq, and } from "drizzle-orm";
import {
  db,
  studentsTable,
  schedulesTable,
  studentStatusesTable,
  activityLogsTable,
} from "@workspace/db";
import {
  GetStudentParams,
  GetStudentResponse,
  UpdateStudentStatusParams,
  UpdateStudentStatusBody,
  UpdateStudentStatusResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/students/:studentId", async (req, res): Promise<void> => {
  const params = GetStudentParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const { studentId } = params.data;

  const [student] = await db
    .select()
    .from(studentsTable)
    .where(eq(studentsTable.id, studentId));

  if (!student) {
    res.status(404).json({ error: "Aluno não encontrado" });
    return;
  }

  const [schedule] = await db
    .select()
    .from(schedulesTable)
    .where(eq(schedulesTable.id, student.scheduleId));

  if (!schedule) {
    res.status(404).json({ error: "Horário não encontrado" });
    return;
  }

  const detail = {
    id: student.id,
    name: student.name,
    grade: student.grade,
    photoUrl: student.photoUrl,
    parentName: student.parentName,
    parentPhone: student.parentPhone,
    medicalNotes: student.medicalNotes ?? "",
    scheduleId: student.scheduleId,
    scheduleName: schedule.name,
    destinationClass: schedule.destinationClass,
    departureTime: schedule.departureTime,
  };

  res.json(GetStudentResponse.parse(detail));
});

router.patch("/students/:studentId/status", async (req, res): Promise<void> => {
  const params = UpdateStudentStatusParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const body = UpdateStudentStatusBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }

  const { studentId } = params.data;
  const { status, scheduleId } = body.data;
  const session = req.session as { monitorId?: number };
  const monitorId = session.monitorId;

  const [student] = await db
    .select()
    .from(studentsTable)
    .where(eq(studentsTable.id, studentId));

  if (!student) {
    res.status(404).json({ error: "Aluno não encontrado" });
    return;
  }

  const [existing] = await db
    .select()
    .from(studentStatusesTable)
    .where(
      and(
        eq(studentStatusesTable.studentId, studentId),
        eq(studentStatusesTable.scheduleId, scheduleId)
      )
    );

  if (status === "unset") {
    // Remove the explicit status record — student goes back to "pending"
    if (existing) {
      await db
        .delete(studentStatusesTable)
        .where(eq(studentStatusesTable.id, existing.id));
    }
  } else {
    // Upsert the status record
    if (existing) {
      await db
        .update(studentStatusesTable)
        .set({ status, updatedAt: new Date() })
        .where(eq(studentStatusesTable.id, existing.id));
    } else {
      await db.insert(studentStatusesTable).values({
        studentId,
        scheduleId,
        status,
        updatedAt: new Date(),
      });
    }

    // Auto-create activity log entries per status
    if (monitorId) {
      let action: string | null = null;
      if (status === "present") action = "retirada";
      else if (status === "absent") action = "confirmacao";
      else if (status === "collected") action = "entrega";

      if (action) {
        await db.insert(activityLogsTable).values({
          monitorId,
          studentId,
          scheduleId,
          action,
        });
      }
    }
  }

  const result = {
    id: student.id,
    name: student.name,
    grade: student.grade,
    photoUrl: student.photoUrl,
    status: status === "unset" ? "unset" : status,
    scheduleId,
  };

  res.json(UpdateStudentStatusResponse.parse(result));
});

export default router;
