import { Router, type IRouter } from "express";
import { eq, and, gte, lt, ilike } from "drizzle-orm";
import {
  db,
  activityLogsTable,
  monitorsTable,
  studentsTable,
  schedulesTable,
} from "@workspace/db";
import {
  ListActivityLogsQueryParams,
  ListActivityLogsResponse,
  ListActivityLogsResponseItem,
  CreateActivityLogBody,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/activity-logs", async (req, res): Promise<void> => {
  const parsed = ListActivityLogsQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { date, monitorId, scheduleId, studentName } = parsed.data;

  const conditions = [];

  if (date) {
    const start = new Date(`${date}T00:00:00.000Z`);
    const end = new Date(`${date}T23:59:59.999Z`);
    conditions.push(gte(activityLogsTable.createdAt, start));
    conditions.push(lt(activityLogsTable.createdAt, end));
  }

  if (monitorId) conditions.push(eq(activityLogsTable.monitorId, monitorId));
  if (scheduleId) conditions.push(eq(activityLogsTable.scheduleId, scheduleId));

  const rows = await db
    .select({
      id: activityLogsTable.id,
      monitorId: activityLogsTable.monitorId,
      monitorName: monitorsTable.name,
      studentName: studentsTable.name,
      grade: studentsTable.grade,
      scheduleName: schedulesTable.name,
      scheduleId: activityLogsTable.scheduleId,
      destinationClass: schedulesTable.destinationClass,
      action: activityLogsTable.action,
      createdAt: activityLogsTable.createdAt,
    })
    .from(activityLogsTable)
    .innerJoin(monitorsTable, eq(activityLogsTable.monitorId, monitorsTable.id))
    .innerJoin(studentsTable, eq(activityLogsTable.studentId, studentsTable.id))
    .innerJoin(schedulesTable, eq(activityLogsTable.scheduleId, schedulesTable.id))
    .where(conditions.length > 0 ? and(...conditions) : undefined)
    .orderBy(activityLogsTable.createdAt);

  // Apply studentName text filter after join (ilike on DB side if supported)
  const filtered = studentName
    ? rows.filter((r) =>
        r.studentName.toLowerCase().includes(studentName.toLowerCase())
      )
    : rows;

  const entries = filtered.map((r) => ({
    ...r,
    createdAt: r.createdAt.toISOString(),
  }));

  res.json(ListActivityLogsResponse.parse(entries));
});

router.post("/activity-logs", async (req, res): Promise<void> => {
  const body = CreateActivityLogBody.safeParse(req.body);
  if (!body.success) {
    res.status(400).json({ error: body.error.message });
    return;
  }

  const session = req.session as any;
  const monitorId: number | undefined = session.monitorId;

  if (!monitorId) {
    res.status(401).json({ error: "Não autenticado" });
    return;
  }

  const { studentId, scheduleId, action } = body.data;

  const [student] = await db
    .select()
    .from(studentsTable)
    .where(eq(studentsTable.id, studentId));

  if (!student) {
    res.status(404).json({ error: "Aluno não encontrado" });
    return;
  }

  const [schedule] = await db
    .select()
    .from(schedulesTable)
    .where(eq(schedulesTable.id, scheduleId));

  if (!schedule) {
    res.status(404).json({ error: "Horário não encontrado" });
    return;
  }

  const [monitor] = await db
    .select()
    .from(monitorsTable)
    .where(eq(monitorsTable.id, monitorId));

  const [log] = await db
    .insert(activityLogsTable)
    .values({ monitorId, studentId, scheduleId, action })
    .returning();

  const entry = {
    id: log.id,
    monitorId: log.monitorId,
    monitorName: monitor?.name ?? "",
    studentName: student.name,
    grade: student.grade,
    scheduleName: schedule.name,
    scheduleId: log.scheduleId,
    destinationClass: schedule.destinationClass,
    action: log.action,
    createdAt: log.createdAt.toISOString(),
  };

  res.status(201).json(ListActivityLogsResponseItem.parse(entry));
});

export default router;
