import { pgTable, serial, integer, text, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { monitorsTable } from "./monitors";
import { studentsTable } from "./students";
import { schedulesTable } from "./schedules";

export const activityLogsTable = pgTable("activity_logs", {
  id: serial("id").primaryKey(),
  monitorId: integer("monitor_id")
    .notNull()
    .references(() => monitorsTable.id),
  studentId: integer("student_id")
    .notNull()
    .references(() => studentsTable.id),
  scheduleId: integer("schedule_id")
    .notNull()
    .references(() => schedulesTable.id),
  action: text("action").notNull(), // "present" | "absent"
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertActivityLogSchema = createInsertSchema(activityLogsTable).omit({ id: true, createdAt: true });
export type InsertActivityLog = z.infer<typeof insertActivityLogSchema>;
export type ActivityLog = typeof activityLogsTable.$inferSelect;
