import { pgTable, serial, text, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const DAY_OF_WEEK_VALUES = [
  "segunda",
  "terca",
  "quarta",
  "quinta",
  "sexta",
] as const;
export type DayOfWeek = (typeof DAY_OF_WEEK_VALUES)[number];

export const schedulesTable = pgTable("schedules", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  destinationClass: text("destination_class").notNull(),
  departureTime: text("departure_time").notNull(),
  returnTime: text("return_time").notNull(),
  dayOfWeek: text("day_of_week").notNull().default("segunda"),
  finalizedAt: timestamp("finalized_at", { withTimezone: true }),
});

export const insertScheduleSchema = createInsertSchema(schedulesTable).omit({ id: true });
export type InsertSchedule = z.infer<typeof insertScheduleSchema>;
export type Schedule = typeof schedulesTable.$inferSelect;
