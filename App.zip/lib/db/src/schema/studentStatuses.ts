import { pgTable, serial, text, integer, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { studentsTable } from "./students";
import { schedulesTable } from "./schedules";

export const studentStatusesTable = pgTable("student_statuses", {
  id: serial("id").primaryKey(),
  studentId: integer("student_id")
    .notNull()
    .references(() => studentsTable.id),
  scheduleId: integer("schedule_id")
    .notNull()
    .references(() => schedulesTable.id),
  status: text("status").notNull().default("absent"),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertStudentStatusSchema = createInsertSchema(studentStatusesTable).omit({ id: true });
export type InsertStudentStatus = z.infer<typeof insertStudentStatusSchema>;
export type StudentStatus = typeof studentStatusesTable.$inferSelect;
